import random
print(random.randrange(1, 10))